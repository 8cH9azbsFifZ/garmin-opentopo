fzk-mde-garmin
==============

<strong>F</strong>rei<strong>z</strong>eit<strong>k</strong>arte <strong>M</strong>ap <strong>D</strong>evelopment <strong>E</strong>nvironment for <strong>G</strong>armin

Deutsch
------
Die Freizeitkarten basieren auf den Daten des OpenStreetMap-Projektes und sind als Universalkarte entwickelt, für

* die Freizeit
* und bei Outdoor-Aktivitäten

Dieses Repository beinhaltet die Entwicklungsumgebung die verwendet wird um die Freizeitkarten zu erzeugen.

### Mehr Informationen

* [Freizeitkarte Hauptseite](https://www.freizeitkarte-osm.de/garmin/de/index.html)
* [Freizeitkarte Karten Entwicklung](https://www.freizeitkarte-osm.de/garmin/de/entwicklung.html)

English
-------
The 'Freizeitkarten' maps are based on data of the OpenStreetMap-Project and are provided as general maps for

* your leisure time
* and for outdoor activities

This repository contains the development environment used for creating the 'Freizeitkarte' maps.

### More Information

* [Freizeitkarte Main Page](https://www.freizeitkarte-osm.de/garmin/en/index.html)
* [Freizeitkarte Map Development](https://www.freizeitkarte-osm.de/garmin/en/development.html)

