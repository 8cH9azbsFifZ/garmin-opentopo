wget.exe

Downloaded from:
http://code.google.com/p/osspack32/downloads/detail?name=wget-1.14.exe&can=2&q=

Purpose:
wget.exe from gnuwin32 ( http://gnuwin32.sourceforge.net/packages/wget.htm ) has even with -q output to standard out... that's 'boring' and disturbing for the checkurl sub
